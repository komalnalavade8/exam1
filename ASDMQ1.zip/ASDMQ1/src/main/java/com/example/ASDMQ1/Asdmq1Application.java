package com.example.ASDMQ1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Asdmq1Application {

	public static void main(String[] args) {
		SpringApplication.run(Asdmq1Application.class, args);
	}

}
